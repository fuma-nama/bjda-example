import bjda.BJDA
import bjda.plugins.supercommand.SuperCommandModule
import bjda.plugins.ui.UIEventModule
import commands.ExampleCommand
import net.dv8tion.jda.api.JDABuilder

fun main() {
    val jda = JDABuilder.createDefault("OTA3OTU1NzgxOTcyOTE4Mjgz.GBO7WT.-GuaagjPpAiPTLZ2sfxlBPGIWT2di8Fovr1RVo")
        .build()
        .awaitReady()

    BJDA.create(jda)
        .install(
            SuperCommandModule(
                ExampleCommand()
            ),
            UIEventModule(),
        )
}